
import './styles/theme.css';
import './styles/global.css';
import { Heading } from './components/Heading';
import { Timer } from 'lucide-react';


function App() {
  
  return (
    <>
      
      <Heading>
        Ola mundo !
        <button>
          <Timer />
        </button>
      </Heading>

      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. 
        Quas voluptatem doloribus deleniti. Earum id, tempore nulla, eos quasi quos 
        accusantium, repellat alias rem doloribus possimus reprehenderit quia 
        obcaecati sit. Blanditiis.
      </p>
    </>
  )
}

export default App
