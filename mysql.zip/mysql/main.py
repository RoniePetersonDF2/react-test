import mysql.connector

Conectar ao MySQL
conn = mysql.connector.connect(
host="localhost",
user="seu_nome_de_usuário",
password="sua_senha",
database="seu_banco_de_dados"
)

cursor = conn.cursor()

Executar um consulta
cursor.execute("SELECT * FROM your_table")
results = cursor.fetchall()

Exibir resultados
para linha em resultados:
print(linha)

Limpar
cursor.close()
conn.close()